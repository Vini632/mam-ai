from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import httpx, json, os, asyncio
from pathlib import Path
from prompts import build_prompt

app = FastAPI(title="MAM-AI", docs_url=None, redoc_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
MODEL = os.getenv("MODEL", "gemma3:4b")
KNOWLEDGE_DIR = Path(__file__).parent / "knowledge"

def load_knowledge() -> str:
    texts = []
    if KNOWLEDGE_DIR.exists():
        for f in KNOWLEDGE_DIR.glob("*.txt"):
            texts.append(f.read_text(encoding="utf-8"))
        for f in KNOWLEDGE_DIR.glob("*.json"):
            texts.append(f.read_text(encoding="utf-8"))
    return "\n\n---\n\n".join(texts)

class ChatRequest(BaseModel):
    mode: str = "chat"       # chat | script | idea
    message: str
    history: list[dict] = [] # [{"role":"user","content":"..."}]
    stream: bool = True

class KnowledgeAdd(BaseModel):
    filename: str
    content: str

@app.get("/health")
async def health():
    try:
        async with httpx.AsyncClient(timeout=3) as c:
            r = await c.get(f"{OLLAMA_URL}/api/tags")
            models = [m["name"] for m in r.json().get("models", [])]
        return {"status": "ok", "ollama": True, "models": models}
    except:
        return {"status": "ok", "ollama": False, "models": []}

@app.get("/models")
async def list_models():
    async with httpx.AsyncClient(timeout=5) as c:
        r = await c.get(f"{OLLAMA_URL}/api/tags")
        return r.json()

@app.post("/chat")
async def chat(req: ChatRequest):
    knowledge = load_knowledge()
    system = build_prompt(req.mode, knowledge)

    messages = [{"role": "system", "content": system}]
    messages += req.history[-10:]  # max 10 turns de histórico
    messages.append({"role": "user", "content": req.message})

    payload = {
        "model": MODEL,
        "messages": messages,
        "stream": req.stream,
        "options": {
            "num_predict": 800,
            "temperature": 0.7,
            "top_p": 0.9,
        }
    }

    if not req.stream:
        async with httpx.AsyncClient(timeout=120) as c:
            r = await c.post(f"{OLLAMA_URL}/api/chat", json=payload)
            data = r.json()
            return {"response": data["message"]["content"]}

    async def stream_gen():
        async with httpx.AsyncClient(timeout=120) as c:
            async with c.stream("POST", f"{OLLAMA_URL}/api/chat", json=payload) as resp:
                async for line in resp.aiter_lines():
                    if not line:
                        continue
                    try:
                        chunk = json.loads(line)
                        token = chunk.get("message", {}).get("content", "")
                        if token:
                            yield f"data: {json.dumps({'token': token})}\n\n"
                        if chunk.get("done"):
                            yield "data: [DONE]\n\n"
                    except:
                        pass

    return StreamingResponse(stream_gen(), media_type="text/event-stream")

@app.post("/knowledge")
async def add_knowledge(data: KnowledgeAdd):
    safe_name = "".join(c for c in data.filename if c.isalnum() or c in "._-")
    if not safe_name.endswith((".txt", ".json")):
        safe_name += ".txt"
    path = KNOWLEDGE_DIR / safe_name
    path.write_text(data.content, encoding="utf-8")
    return {"saved": str(path.name)}

@app.get("/knowledge")
async def list_knowledge():
    files = []
    if KNOWLEDGE_DIR.exists():
        for f in KNOWLEDGE_DIR.iterdir():
            if f.suffix in (".txt", ".json"):
                files.append({"name": f.name, "size": f.stat().st_size})
    return {"files": files}

@app.delete("/knowledge/{filename}")
async def delete_knowledge(filename: str):
    path = KNOWLEDGE_DIR / filename
    if path.exists() and path.parent == KNOWLEDGE_DIR:
        path.unlink()
        return {"deleted": filename}
    raise HTTPException(404, "Arquivo não encontrado")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
