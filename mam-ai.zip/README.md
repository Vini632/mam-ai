# MAM·AI — Kit Completo

## Pré-requisitos
- Python 3.10+
- Ollama rodando → https://ollama.com
- Modelo: `ollama pull gemma3:4b`

## Rodar
```bash
chmod +x start.sh && ./start.sh
```
Acesse: http://localhost:3000

## Variáveis de ambiente (opcional)
```bash
export OLLAMA_URL=http://localhost:11434
export MODEL=gemma3:4b
```

## Estrutura
```
mam-ai/
├── backend/
│   ├── main.py          # FastAPI API
│   ├── prompts.py       # System prompts
│   ├── requirements.txt
│   └── knowledge/
│       └── mam_base.txt # Contexto base (editável)
├── frontend/
│   └── index.html       # SPA completo
├── start.sh
└── README.md
```

## Adicionar contexto/RAG
Coloque arquivos `.txt` ou `.json` em `backend/knowledge/`.
São injetados automaticamente em todos os prompts.
Ou use a aba **Base de Conhecimento** no site.

## Acesso externo (celular fora da rede)
```bash
ngrok http 8000
# Cole a URL gerada em Configurações > URL do Backend
```

## Endpoints da API
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | /health | Status do servidor |
| POST | /chat | Chat/stream (mode: chat/script/idea) |
| GET/POST/DELETE | /knowledge | Gerenciar base de conhecimento |
